export * as Animated from "./animated";

// 타입 export
export type {
  BoxProps,
  SectionProps,
  CardProps,
  ListProps,
  ListItemProps,
} from "./animated";
